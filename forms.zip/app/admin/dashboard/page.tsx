"use client"

import { DashboardContent } from "@/components/dashboard-content"

export default function AdminDashboardPage() {
  return <DashboardContent />
}
