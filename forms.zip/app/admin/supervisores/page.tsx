"use client"

import { SupervisorManagement } from "@/components/supervisor-management"

export default function AdminSupervisoresPage() {
  return <SupervisorManagement />
}
